#include <stdio.h>

// -----------------------------------------
// Tester Function Prototypes

    // -----------------------------------------
    // Unit Tests:

    // Integer testers
void test01_inputInt();
void test02_inputIntPositive();
void test03_inputIntRange();
void test04_inputIntRange();

// Char tester
void test05_inputCharOption();

// C string testers
void test06_inputCString();
void test07_inputCString();
void test08_inputCString();

// phone
void test09_displayPhone();

// -----------------------------------------